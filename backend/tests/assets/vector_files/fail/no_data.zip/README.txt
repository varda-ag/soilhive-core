Sampling campaign notes.
Not a data file; the loader must ignore it.
